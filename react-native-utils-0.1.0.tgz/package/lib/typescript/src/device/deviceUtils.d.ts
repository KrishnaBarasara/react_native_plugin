export declare const getDeviceInfo: () => {
    brand: string;
    model: string;
    systemVersion: string;
};
export declare const getPlatform: () => "ios" | "android" | "windows" | "macos" | "web";
export declare const isConnected: () => Promise<boolean | null>;
//# sourceMappingURL=deviceUtils.d.ts.map