export declare const showToast: (message: string, type?: "success" | "error") => void;
//# sourceMappingURL=toastUtils.d.ts.map