export declare const apiGet: (url: string, params?: Record<string, any>) => Promise<any>;
export declare const apiPost: (url: string, body?: any) => Promise<any>;
export declare const handleError: (error: any) => never;
//# sourceMappingURL=apiClient.d.ts.map