export declare const setItem: (key: string, value: any) => Promise<void>;
export declare const getItem: (key: string) => Promise<any>;
export declare const clearItem: (key: string) => Promise<void>;
//# sourceMappingURL=storageHelper.d.ts.map