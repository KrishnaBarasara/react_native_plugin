export type ThemeType = 'light' | 'dark';
export declare const setTheme: (theme: ThemeType) => void;
export declare const toggleDarkMode: () => void;
export declare const useTheme: () => ThemeType;
//# sourceMappingURL=themeManager.d.ts.map