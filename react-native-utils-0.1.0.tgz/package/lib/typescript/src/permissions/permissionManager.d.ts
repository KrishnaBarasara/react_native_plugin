export declare const checkPermission: (permission: any) => Promise<boolean>;
export declare const requestPermission: (permission: any) => Promise<boolean>;
export declare const openSettings: () => Promise<void>;
//# sourceMappingURL=permissionManager.d.ts.map