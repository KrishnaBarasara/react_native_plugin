import React, { type ReactNode } from 'react';
import { type ViewStyle } from 'react-native';
interface CardProps {
    children: ReactNode;
    style?: ViewStyle;
    shadow?: boolean;
}
export declare const Card: React.FC<CardProps>;
export {};
//# sourceMappingURL=Card.d.ts.map