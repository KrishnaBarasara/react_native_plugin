import React from 'react';
interface LoaderProps {
    message?: string;
    size?: 'small' | 'large';
    color?: string;
}
export declare const Loader: React.FC<LoaderProps>;
export {};
//# sourceMappingURL=Loader.d.ts.map