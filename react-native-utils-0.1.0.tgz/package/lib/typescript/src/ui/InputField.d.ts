import React from 'react';
import { type TextInputProps } from 'react-native';
interface InputFieldProps extends TextInputProps {
    label?: string;
    error?: string;
}
export declare const InputField: React.FC<InputFieldProps>;
export {};
//# sourceMappingURL=InputField.d.ts.map