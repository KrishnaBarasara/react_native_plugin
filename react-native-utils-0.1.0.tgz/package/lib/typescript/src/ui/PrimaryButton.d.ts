export declare const PrimaryButton: ({ title, onPress, }: {
    title: string;
    onPress: () => void;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=PrimaryButton.d.ts.map