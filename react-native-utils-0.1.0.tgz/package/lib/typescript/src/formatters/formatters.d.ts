export declare const formatDate: (date: Date) => string | undefined;
export declare const formatCurrency: (value: number) => string;
export declare const capitalize: (text: string) => string;
//# sourceMappingURL=formatters.d.ts.map